export const metadata={title:'Sendar Next.js local starter',robots:{index:false,follow:false}};
export default function Layout({children}){return <html lang="en"><body style={{fontFamily:'system-ui',maxWidth:720,margin:'60px auto',padding:24,lineHeight:1.6}}>{children}</body></html>;}
