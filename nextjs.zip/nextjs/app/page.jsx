'use client';
import {useState} from 'react';
export default function Page(){
 const[result,setResult]=useState(null),[busy,setBusy]=useState(false);
 async function run(){setBusy(true);try{const r=await fetch('/api/demo',{method:'POST'});setResult(await r.json());}catch{setResult({error:'Request interrupted. Check the Sendar log before another live attempt.'});}finally{setBusy(false);}}
 return <main><p>SENDAR · NEXT.JS APP ROUTER</p><h1>Preview your first application email</h1><p>This local demo previews a request by default. It sends only when you set SENDAR_SEND=1 on the server. Sender and recipient come from your environment, never the browser.</p><button disabled={busy} onClick={run}>{busy?'Working…':'Run configured demo'}</button><pre aria-live="polite" style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{result?JSON.stringify(result,null,2):'Ready. No request has been sent.'}</pre><p>After a live attempt, check its message ID in Sendar before retrying. This demo is disabled in production.</p></main>;
}
