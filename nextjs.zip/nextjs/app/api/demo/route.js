import { handleDemo } from '../../../lib/demo.mjs';
export const runtime='nodejs';
export async function POST(request){return handleDemo(request);}
