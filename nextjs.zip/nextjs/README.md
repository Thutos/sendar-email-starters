# Sendar + Next.js: preview to first send

A complete local App Router example. Requires Node 20.9 or newer. Versions are pinned in package.json and the lockfile.

1. Run `npm ci` in this directory.
2. Copy `.env.example` to `.env.local`. Leave `SENDAR_SEND=0`.
3. Run `npm run dev`, open http://127.0.0.1:3000 and click **Run configured demo**.
4. Expect JSON with `mode: "preview"` and the message payload. No provider request occurs and no account is needed for this preview.
5. When you choose to send, create a Sendar account, verify your sending domain, and create an API key. Set SENDAR_API_KEY, SENDAR_FROM and SENDAR_TO (a recipient you control) in .env.local. Set SENDAR_SEND=1, restart the server and click once.
6. Expect a message ID and status. Inspect the email log and recipient inbox. A sent status is provider acceptance, not guaranteed inbox delivery. On an error or timeout, inspect the log before trying again.

`npm test` uses injected fake fetch responses; it never sends email. `npm run build` checks the app. The demo API returns 404 in production even if sending is enabled. No secrets use NEXT_PUBLIC variables.

For a real application, move the send into your authenticated business-event handler, authorise the recipient from server records, validate content, enforce rate limits and use a durable event ledger. Never expose an unauthenticated endpoint accepting arbitrary recipients. Keep provider/message IDs for uncertain-outcome reconciliation. Do not automatically fail over a message whose acceptance is unknown.

Migration guides: https://sendar.app/migrate
API contract: https://sendar.app/docs/send-email
Next.js route handlers: https://nextjs.org/docs/app/getting-started/route-handlers
